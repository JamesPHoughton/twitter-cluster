#ifndef COS_H
#define COS_H

#include "common.h"
#include "cliques.h"
#include "matrix.h"

extern int cos_();

#endif /* COS_H */
