#ifndef COSPOC_H
#define COSPOC_H

#include "common.h"
#include "cliques.h"

extern int cospoc();

#endif /* COSPOC_H */
