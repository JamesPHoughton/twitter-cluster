#ifndef OUTPUT_COMMUNITIES_H
#define OUTPUT_COMMUNITIES_H

#include "dsforest.h"

extern int write_found_communities_to_file();

#endif /* OUTPUT_COMMUNITIES_H */
